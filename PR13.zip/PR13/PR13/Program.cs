﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выполнил Стародубцев Максим группа ИСП.20А");
            //запись исходных данных в файл Input.txt
            string path = @"Input.txt";
            double P =0.017e-6;
            double d = 0.1e-4;
            double L = 0.3;
            StreamWriter sw = new StreamWriter(path, false);
            sw.WriteLine(P);
            sw.WriteLine(d);
            sw.WriteLine(L);
            sw.Close();
            Console.WriteLine("Исходные данные:");
            Console.WriteLine($"C1 = {P}");
            Console.WriteLine($"C2 = {d}");
            Console.WriteLine($"C3 = {L}");
            Console.WriteLine("Запись произведена");
            Console.ReadKey();


            //чтение из файла Input.txt
            StreamReader sr = new StreamReader(path);
            double P_read = Convert.ToDouble(sr.ReadLine());
            double d_read = Convert.ToDouble(sr.ReadLine());
            double L_read = Convert.ToDouble(sr.ReadLine());

            //вычисление результата по формуле
            double solve = Math.PI*d_read*d_read/4;//формула
            solve=P_read*L_read/solve;

            //запись результата в файл Result.txt
            string path1 = @"Result.txt";
            StreamWriter sw1 = new StreamWriter(path1, false);
            sw1.WriteLine(solve);
            sw1.Close();
            Console.WriteLine($"Результат: {solve}");
            Console.WriteLine("Подсчет и запись выполнены");
            Console.ReadKey();
        }
    }
}
